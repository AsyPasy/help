package com.ultiwither.plugin;

import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class UltiWitherPlugin extends JavaPlugin {

    private UltiWitherListener listener;

    @Override
    public void onEnable() {
        listener = new UltiWitherListener(this);
        getServer().getPluginManager().registerEvents(listener, this);
        getLogger().info("UltiWither plugin enabled!");
    }

    @Override
    public void onDisable() {
        if (listener != null) {
            listener.cleanup();
        }
        getLogger().info("UltiWither plugin disabled!");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (command.getName().equalsIgnoreCase("spawnultiwither")) {
            if (!(sender instanceof Player player)) {
                sender.sendMessage("Only players can use this command!");
                return true;
            }
            UltiWitherBoss boss = new UltiWitherBoss(this, player.getLocation());
            listener.registerBoss(boss);
            player.sendMessage("§4§lThe Ultimate Wither has been summoned!");
            return true;
        }
        return false;
    }
}
