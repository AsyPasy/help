package com.ultiwither.plugin;

import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.*;
import org.bukkit.metadata.MetadataValue;

import java.util.*;

public class UltiWitherListener implements Listener {

    private final UltiWitherPlugin plugin;

    /** All active boss instances keyed by wither entity UUID. */
    private final Map<UUID, UltiWitherBoss> activeBosses = new HashMap<>();

    public UltiWitherListener(UltiWitherPlugin plugin) {
        this.plugin = plugin;
    }

    // ── Boss registration ────────────────────────────────────────────────────
    public void registerBoss(UltiWitherBoss boss) {
        activeBosses.put(boss.getWither().getUniqueId(), boss);
    }

    // ── Entity death ─────────────────────────────────────────────────────────
    @EventHandler(priority = EventPriority.MONITOR)
    public void onEntityDeath(EntityDeathEvent event) {
        Entity entity = event.getEntity();

        // Boss dies
        if (entity instanceof Wither && hasMeta(entity, UltiWitherBoss.META_ULTI_WITHER)) {
            UltiWitherBoss boss = activeBosses.remove(entity.getUniqueId());
            if (boss != null) {
                boss.die();
                broadcastNearby(entity.getLocation(), 100,
                        "§4§l✦ The Ultimate Wither has been slain! ✦");
            }
        }
    }

    // ── Damage events ────────────────────────────────────────────────────────

    /**
     * Intercept ALL damage dealt to the Ulti-Wither so we can scale it
     * (vanilla skulls deal skull-damage amount instead of default).
     */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onWitherDamaged(EntityDamageByEntityEvent event) {
        if (!(event.getEntity() instanceof Wither wither)) return;
        if (!hasMeta(wither, UltiWitherBoss.META_ULTI_WITHER)) return;

        Entity damager = event.getDamager();

        // Projectile damage from a vanilla wither skull fired by anything else → keep default
        // Our special skulls are handled in onSkullHit; here we only block the self-damage loop.
        if (damager instanceof WitherSkull skull && skull.getShooter() instanceof Wither) {
            // Don't let the wither hurt itself
            event.setCancelled(true);
        }
    }

    /**
     * Handle our custom skulls hitting players (or blocks).
     */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onProjectileHit(ProjectileHitEvent event) {
        if (!(event.getEntity() instanceof WitherSkull skull)) return;

        boolean isExplosive   = hasMeta(skull, UltiWitherBoss.META_EXPLO_SKULL);
        boolean isTriplicate  = hasMeta(skull, UltiWitherBoss.META_TRIPLICATE_SKULL);

        if (!isExplosive && !isTriplicate) return;

        // Prevent default explosion
        event.setCancelled(true);
        skull.remove();

        Entity hitEntity = event.getHitEntity();
        Location hitLoc  = skull.getLocation();

        // Fancy explosion VFX (no block damage)
        hitLoc.getWorld().spawnParticle(Particle.EXPLOSION, hitLoc, 8, 0.3, 0.3, 0.3, 0);
        hitLoc.getWorld().playSound(hitLoc, Sound.ENTITY_GENERIC_EXPLODE, 1.5f, 1.2f);

        if (!(hitEntity instanceof Player player)) return;

        UltiWitherBoss boss = findBossFromSkull(skull);

        if (isExplosive) {
            // Deal explosive damage
            player.damage(UltiWitherBoss.getExplosiveSkullDmg(),
                    boss != null ? boss.getWither() : null);
            player.sendMessage("§c§lYou were hit by an Explosive Skull! (30 dmg)");

            // Triplicate: fire 3 more skulls at this player
            if (boss != null) {
                boss.launchTriplicateSkulls(player);
                player.sendMessage("§4§l⚠ The skull triplicates! Punch them to deflect!");
            }

        } else {
            // Triplicate skull
            player.damage(UltiWitherBoss.getTriplicateSkullDmg(),
                    boss != null ? boss.getWither() : null);
            player.sendMessage("§c§lA Triplicate Skull hit you! (20 dmg)");

            if (boss != null) boss.clearTriplicateCount(player.getUniqueId());
        }
    }

    /**
     * Allow players to deflect triplicate skulls by punching (left-clicking) them.
     */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPlayerAttackSkull(EntityDamageByEntityEvent event) {
        if (!(event.getEntity() instanceof WitherSkull skull)) return;
        if (!(event.getDamager() instanceof Player player)) return;

        boolean isExplosive  = hasMeta(skull, UltiWitherBoss.META_EXPLO_SKULL);
        boolean isTriplicate = hasMeta(skull, UltiWitherBoss.META_TRIPLICATE_SKULL);

        if (!isExplosive && !isTriplicate) return;

        // Deflect / destroy the skull
        event.setCancelled(true);
        skull.remove();

        skull.getLocation().getWorld().spawnParticle(
                Particle.SMOKE, skull.getLocation(), 10, 0.2, 0.2, 0.2, 0.05);
        skull.getLocation().getWorld().playSound(
                skull.getLocation(), Sound.ENTITY_ARROW_HIT_PLAYER, 1f, 1.5f);

        player.sendMessage("§a§lYou deflected the skull!");

        if (isTriplicate) {
            UltiWitherBoss boss = findBossFromSkull(skull);
            if (boss != null) boss.clearTriplicateCount(player.getUniqueId());
        }
    }

    /**
     * Vanilla wither skull damage → replace with our skull-damage value.
     */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onVanillaSkullDamage(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof WitherSkull skull)) return;
        if (!(skull.getShooter() instanceof Wither wither)) return;
        if (!hasMeta(wither, UltiWitherBoss.META_ULTI_WITHER)) return;

        // Skip our custom skulls (handled elsewhere)
        if (hasMeta(skull, UltiWitherBoss.META_EXPLO_SKULL)) return;
        if (hasMeta(skull, UltiWitherBoss.META_TRIPLICATE_SKULL)) return;

        // Override damage to our SKULL_DAMAGE constant
        event.setDamage(UltiWitherBoss.getSkullDamage());
    }

    // ── Cleanup ──────────────────────────────────────────────────────────────
    public void cleanup() {
        activeBosses.values().forEach(UltiWitherBoss::cleanup);
        activeBosses.clear();
    }

    // ── Helpers ──────────────────────────────────────────────────────────────
    private boolean hasMeta(Entity entity, String key) {
        return entity.hasMetadata(key);
    }

    private String getMetaString(Entity entity, String key) {
        List<MetadataValue> vals = entity.getMetadata(key);
        return vals.isEmpty() ? null : vals.get(0).asString();
    }

    /** Find the boss that owns a given skull by checking all bosses. */
    private UltiWitherBoss findBossFromSkull(WitherSkull skull) {
        if (skull.getShooter() instanceof Wither wither) {
            return activeBosses.get(wither.getUniqueId());
        }
        return null;
    }

    private void broadcastNearby(Location loc, double radius, String msg) {
        for (Entity e : loc.getWorld().getNearbyEntities(loc, radius, radius, radius)) {
            if (e instanceof Player p) p.sendMessage(msg);
        }
    }
}
