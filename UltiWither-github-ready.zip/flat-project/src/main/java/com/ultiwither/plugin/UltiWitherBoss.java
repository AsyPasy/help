package com.ultiwither.plugin;

import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.entity.*;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import java.util.*;

public class UltiWitherBoss {

    // ── Constants ────────────────────────────────────────────────────────────
    private static final double MAX_HEALTH          = 1000.0;
    private static final double SKULL_DAMAGE        = 15.0;
    private static final double SHOCKWAVE_DAMAGE    = 40.0;
    private static final double EXPLOSIVE_SKULL_DMG = 30.0;
    private static final double TRIPLICATE_SKL_DMG  = 20.0;
    private static final double MINION_HEALTH       = 100.0;
    private static final double MINION_MELEE_DAMAGE = 5.0;

    private static final double REGEN_PERCENT  = 0.05;   // 5 % per interval
    private static final long   REGEN_INTERVAL = 100L;   // 5 s  (20 t/s × 5)

    private static final long SHOCKWAVE_COOLDOWN = 30 * 20L;  // 30 s in ticks
    private static final long MINION_COOLDOWN    = 50 * 20L;  // 50 s in ticks

    // Metadata keys ─────────────────────────────────────────────────────────
    public static final String META_ULTI_WITHER       = "ultiwither_boss";
    public static final String META_EXPLO_SKULL       = "ultiwither_explosive_skull";
    public static final String META_TRIPLICATE_SKULL  = "ultiwither_triplicate_skull";
    public static final String META_MINION            = "ultiwither_minion";

    // ── State ────────────────────────────────────────────────────────────────
    private final UltiWitherPlugin plugin;
    private Wither wither;
    private final BossBar bossBar;
    private boolean alive = false;

    // combat flag – regen only fires when a player has been nearby recently
    private boolean inCombat = false;

    private long lastShockwaveTick = -SHOCKWAVE_COOLDOWN;
    private long lastMinionTick    = -MINION_COOLDOWN;

    /** Players currently targeted by a triplicate skull (max 3 skulls). */
    private final Map<UUID, Integer> triplicateSkulls = new HashMap<>();

    private final List<BukkitTask> tasks = new ArrayList<>();

    // ── Constructor ──────────────────────────────────────────────────────────
    public UltiWitherBoss(UltiWitherPlugin plugin, Location spawnLocation) {
        this.plugin = plugin;

        bossBar = Bukkit.createBossBar(
                "§4§lULTIMATE WITHER §c[1000/1000]",
                BarColor.RED, BarStyle.SEGMENTED_20);

        spawnWither(spawnLocation);
        startTasks();
    }

    // ── Spawn ────────────────────────────────────────────────────────────────
    private void spawnWither(Location loc) {
        wither = (Wither) loc.getWorld().spawnEntity(loc, EntityType.WITHER);
        wither.setCustomName("§4§lUltimate Wither");
        wither.setCustomNameVisible(true);
        wither.setMetadata(META_ULTI_WITHER, new FixedMetadataValue(plugin, true));
        wither.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, Integer.MAX_VALUE, 0, false, false));

        AttributeInstance maxHp = wither.getAttribute(Attribute.MAX_HEALTH);
        if (maxHp != null) maxHp.setBaseValue(MAX_HEALTH);
        wither.setHealth(MAX_HEALTH);

        alive = true;
    }

    // ── Periodic Tasks ───────────────────────────────────────────────────────
    private void startTasks() {
        // Main AI loop – runs every tick
        tasks.add(new BukkitRunnable() {
            @Override public void run() {
                if (!alive || wither == null || wither.isDead()) { cancel(); return; }
                tick();
            }
        }.runTaskTimer(plugin, 1L, 1L));

        // Regeneration – every 5 s
        tasks.add(new BukkitRunnable() {
            @Override public void run() {
                if (!alive || wither == null || wither.isDead()) { cancel(); return; }
                regenTick();
            }
        }.runTaskTimer(plugin, REGEN_INTERVAL, REGEN_INTERVAL));
    }

    /** Called every game tick. */
    private void tick() {
        long currentTick = wither.getWorld().getFullTime();

        // Detect nearby players → enter combat
        List<Player> nearbyPlayers = getNearbyPlayers(30);
        inCombat = !nearbyPlayers.isEmpty();
        updateBossBar(nearbyPlayers);

        if (!inCombat) return;

        // ── Shockwave ──────────────────────────────────────────────────────
        if (currentTick - lastShockwaveTick >= SHOCKWAVE_COOLDOWN) {
            List<Player> inRange = getNearbyPlayers(10);
            if (!inRange.isEmpty()) {
                doShockwave(inRange);
                lastShockwaveTick = currentTick;
            }
        }

        // ── Explosive skull launch ─────────────────────────────────────────
        // Fire roughly every 4 s at the nearest player
        if (currentTick % 80 == 0) {
            Player target = getNearestPlayer(40);
            if (target != null) launchExplosiveSkull(target);
        }

        // ── Minion summon ──────────────────────────────────────────────────
        if (currentTick - lastMinionTick >= MINION_COOLDOWN) {
            summonMinions();
            lastMinionTick = currentTick;
        }
    }

    // ── Regeneration ────────────────────────────────────────────────────────
    private void regenTick() {
        if (!inCombat) return;
        double current = wither.getHealth();
        if (current <= 0) return;
        double regen = MAX_HEALTH * REGEN_PERCENT;
        double newHp = Math.min(MAX_HEALTH, current + regen);
        wither.setHealth(newHp);
        wither.getWorld().spawnParticle(Particle.HEART, wither.getLocation().add(0, 2, 0), 5, 0.5, 0.5, 0.5, 0);
    }

    // ── Shockwave ───────────────────────────────────────────────────────────
    private void doShockwave(List<Player> targets) {
        Location center = wither.getLocation();

        // Visual / sound effects
        center.getWorld().spawnParticle(Particle.EXPLOSION, center, 10, 3, 0.5, 3, 0);
        center.getWorld().playSound(center, Sound.ENTITY_GENERIC_EXPLODE, 2f, 0.6f);

        for (Player p : targets) {
            p.damage(SHOCKWAVE_DAMAGE, wither);
            // Knockback away from wither
            Vector knockback = p.getLocation().toVector()
                    .subtract(center.toVector())
                    .normalize()
                    .multiply(1.5)
                    .setY(0.6);
            p.setVelocity(knockback);
            p.sendMessage("§c§lThe Wither smashes the ground with a devastating shockwave!");
        }

        // Ground crack particles
        for (int i = 0; i < 30; i++) {
            double angle = (2 * Math.PI / 30) * i;
            Location ring = center.clone().add(Math.cos(angle) * 5, 0, Math.sin(angle) * 5);
            center.getWorld().spawnParticle(Particle.SMOKE, ring, 3, 0.2, 0.1, 0.2, 0.05);
        }
    }

    // ── Explosive Skull ──────────────────────────────────────────────────────
    /**
     * Fires a slow-moving skull (50 % speed) tagged as an explosive skull.
     * The listener handles explosion damage and triplicate logic.
     */
    void launchExplosiveSkull(Player target) {
        Location origin = wither.getEyeLocation();
        Vector dir = target.getEyeLocation().toVector()
                .subtract(origin.toVector())
                .normalize()
                .multiply(0.6);   // 2× slower than a normal skull (~1.2)

        WitherSkull skull = (WitherSkull) wither.getWorld()
                .spawnEntity(origin, EntityType.WITHER_SKULL);
        skull.setVelocity(dir);
        skull.setCharged(false);
        skull.setMetadata(META_EXPLO_SKULL, new FixedMetadataValue(plugin, target.getUniqueId().toString()));
        skull.setShooter(wither);

        wither.getWorld().playSound(origin, Sound.ENTITY_WITHER_SHOOT, 1.5f, 0.8f);
    }

    /**
     * Fires up to 3 triplicate skulls after the explosive skull hits the player.
     */
    void launchTriplicateSkulls(Player target) {
        int already = triplicateSkulls.getOrDefault(target.getUniqueId(), 0);
        if (already >= 3) return;

        int toFire = Math.min(3, 3 - already);
        for (int i = 0; i < toFire; i++) {
            final int idx = i;
            new BukkitRunnable() {
                @Override public void run() {
                    if (!alive || wither == null || wither.isDead()) return;
                    if (target.isDead()) return;

                    Location origin = wither.getEyeLocation();
                    // slight spread
                    Vector dir = target.getEyeLocation().toVector()
                            .subtract(origin.toVector())
                            .normalize();
                    dir.add(new Vector(
                            (Math.random() - 0.5) * 0.1,
                            (Math.random() - 0.5) * 0.1,
                            (Math.random() - 0.5) * 0.1))
                       .normalize()
                       .multiply(0.6);

                    WitherSkull skull = (WitherSkull) wither.getWorld()
                            .spawnEntity(origin, EntityType.WITHER_SKULL);
                    skull.setVelocity(dir);
                    skull.setCharged(false);
                    skull.setMetadata(META_TRIPLICATE_SKULL,
                            new FixedMetadataValue(plugin, target.getUniqueId().toString()));
                    skull.setShooter(wither);
                }
            }.runTaskLater(plugin, 5L * idx);
        }

        triplicateSkulls.put(target.getUniqueId(), already + toFire);
    }

    /** Clears the triplicate counter for a player (call after all 3 skulls resolved). */
    void clearTriplicateCount(UUID playerId) {
        triplicateSkulls.remove(playerId);
    }

    // ── Minion Summon ────────────────────────────────────────────────────────
    private void summonMinions() {
        Location base = wither.getLocation();
        for (int i = 0; i < 2; i++) {
            double angle = Math.PI * i;
            Location spawnLoc = base.clone().add(Math.cos(angle) * 3, 0, Math.sin(angle) * 3);

            WitherSkeleton skeleton = (WitherSkeleton) base.getWorld()
                    .spawnEntity(spawnLoc, EntityType.WITHER_SKELETON);
            skeleton.setCustomName("§8§lWither Minion");
            skeleton.setCustomNameVisible(true);
            skeleton.setMetadata(META_MINION, new FixedMetadataValue(plugin, true));

            AttributeInstance maxHp = skeleton.getAttribute(Attribute.MAX_HEALTH);
            if (maxHp != null) maxHp.setBaseValue(MINION_HEALTH);
            skeleton.setHealth(MINION_HEALTH);

            AttributeInstance dmg = skeleton.getAttribute(Attribute.ATTACK_DAMAGE);
            if (dmg != null) dmg.setBaseValue(MINION_MELEE_DAMAGE);
        }

        base.getWorld().playSound(base, Sound.ENTITY_WITHER_AMBIENT, 1.5f, 0.7f);
        base.getWorld().spawnParticle(Particle.SMOKE, base, 30, 1.5, 1, 1.5, 0.05);

        getNearbyPlayers(50).forEach(p ->
                p.sendMessage("§8§lThe Ultimate Wither summons Wither Skeleton minions!"));
    }

    // ── Utilities ────────────────────────────────────────────────────────────
    private List<Player> getNearbyPlayers(double radius) {
        if (wither == null) return Collections.emptyList();
        List<Player> result = new ArrayList<>();
        for (Entity e : wither.getNearbyEntities(radius, radius, radius)) {
            if (e instanceof Player p && !p.isDead()) result.add(p);
        }
        return result;
    }

    private Player getNearestPlayer(double radius) {
        Player nearest = null;
        double minDist = Double.MAX_VALUE;
        for (Player p : getNearbyPlayers(radius)) {
            double d = p.getLocation().distanceSquared(wither.getLocation());
            if (d < minDist) { minDist = d; nearest = p; }
        }
        return nearest;
    }

    private void updateBossBar(List<Player> nearby) {
        double hp = wither.getHealth();
        double pct = hp / MAX_HEALTH;
        bossBar.setTitle(String.format("§4§lULTIMATE WITHER §c[%.0f/%.0f]", hp, MAX_HEALTH));
        bossBar.setProgress(Math.max(0, Math.min(1, pct)));

        Set<Player> current = new HashSet<>(bossBar.getPlayers());
        Set<Player> target  = new HashSet<>(nearby);

        current.stream().filter(p -> !target.contains(p)).forEach(bossBar::removePlayer);
        target.stream().filter(p -> !current.contains(p)).forEach(bossBar::addPlayer);
    }

    // ── Getters ──────────────────────────────────────────────────────────────
    public Wither getWither()   { return wither; }
    public boolean isAlive()    { return alive;  }

    // ── Cleanup ──────────────────────────────────────────────────────────────
    public void die() {
        alive = false;
        bossBar.removeAll();
        bossBar.setVisible(false);
        tasks.forEach(BukkitTask::cancel);
        tasks.clear();

        if (wither != null && !wither.isDead()) {
            wither.getWorld().playSound(wither.getLocation(), Sound.ENTITY_WITHER_DEATH, 2f, 0.8f);
            wither.getWorld().spawnParticle(Particle.EXPLOSION_EMITTER,
                    wither.getLocation().add(0, 1, 0), 5, 1, 1, 1, 0);
        }
    }

    public void cleanup() {
        alive = false;
        bossBar.removeAll();
        tasks.forEach(BukkitTask::cancel);
    }

    // Static getters used by the listener
    public static double getSkullDamage()       { return SKULL_DAMAGE; }
    public static double getExplosiveSkullDmg() { return EXPLOSIVE_SKULL_DMG; }
    public static double getTriplicateSkullDmg(){ return TRIPLICATE_SKL_DMG; }
}
